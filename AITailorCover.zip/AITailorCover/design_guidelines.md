# Design Guidelines: AI Job Application Assistant

## Design Approach
**System:** Material Design with Linear-inspired simplicity
**Rationale:** Utility-focused productivity tool requiring clear hierarchy, efficient workflows, and minimal visual distraction. User requested "clean, simple styling" - prioritizing function over decorative elements.

## Core Design Principles
1. **Clarity First:** Form inputs are the hero - everything serves the workflow
2. **Minimal Distraction:** No hero images, no marketing fluff - pure utility
3. **Progressive Disclosure:** Guide users through the 3-step process clearly
4. **Instant Feedback:** Clear loading states and success indicators

## Layout System

**Spacing Units:** Tailwind 4, 6, 8, 12 for consistent rhythm
- Component padding: p-6 to p-8
- Section spacing: gap-6 to gap-8
- Container margins: mx-4 md:mx-auto

**Container Strategy:**
- Max width: max-w-4xl centered (optimal for form readability)
- Single column layout throughout
- Responsive padding: px-4 md:px-8

**Viewport Approach:**
- Natural height based on content
- No forced viewport constraints
- Header: py-8
- Main content: py-12
- Form sections: space-y-6

## Typography

**Families:** 
- Inter (headings and UI)
- System fonts fallback

**Hierarchy:**
- App title: text-2xl md:text-3xl font-bold
- Section labels: text-sm font-semibold uppercase tracking-wide
- Input labels: text-base font-medium
- Helper text: text-sm
- Button text: text-base font-semibold

## Component Library

**Header:**
- App title and subtitle centered
- Brief instructional text (1-2 sentences)
- Subtle border-bottom separator

**Form Sections (3 distinct cards):**
1. Job Description Input
2. Resume Input  
3. Generated Cover Letter Output

**Card Structure:**
- Rounded corners: rounded-lg
- Padding: p-6
- Border: border subtle
- Shadow: shadow-sm
- Labels above inputs with mb-3
- Helper text below inputs with mt-2

**Text Areas:**
- Border: border-2 focus state distinct
- Rounded: rounded-md
- Padding: p-4
- Min height: Job Description (h-48), Resume (h-64), Output (h-80)
- Monospace font for better text scanning
- Resize: vertical only

**Primary Button:**
- Full width on mobile, auto width centered on desktop
- Padding: px-8 py-4
- Rounded: rounded-lg
- Font: font-semibold
- Icon: Include sparkle/magic icon from Heroicons
- Loading state: Spinner icon + "Generating..." text

**Secondary Actions:**
- "Copy to Clipboard" button below output
- Subtle styling: border with transparent background
- Icon: Document duplicate from Heroicons

**Loading State:**
- Disable button during generation
- Show spinner icon
- Dim/disable text areas
- Optional: Subtle pulse animation on output area

**Empty States:**
- Output area shows placeholder: "Your tailored cover letter will appear here..."
- Light italic text style

**Icons:** Heroicons (CDN)
- Document text for text areas
- Sparkles for generate button
- Clipboard copy for copy action
- Check circle for success confirmation

## Interaction Patterns

**Flow:**
1. User pastes job description → visual confirmation (character count)
2. User pastes resume → visual confirmation (character count)
3. Click generate → button disabled, loading state
4. Output appears → success state, enable copy button
5. Copy button → brief "Copied!" confirmation

**Validation:**
- Require both inputs before enabling generate button
- Show character counts for inputs
- Max character limits to prevent API issues

**Responsive Behavior:**
- Mobile: Full-width cards, stacked layout
- Desktop: Max-width container, generous whitespace
- Text areas maintain usability across breakpoints

## Images
**No images required** - This is a pure utility application. Visual focus should remain on the form inputs and generated content.

## Accessibility
- All text areas have visible labels
- Proper focus states with distinct borders
- Keyboard navigation works throughout
- Loading states announced for screen readers
- Error messages clearly associated with inputs

## Key Differentiators
- **Not a marketing page:** No hero section, no feature grids
- **Form-first design:** Inputs are prominent, generously sized
- **Workflow clarity:** Linear progression from input → generate → output
- **Professional restraint:** Clean without being sterile, functional without being boring