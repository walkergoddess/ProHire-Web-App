# AI Job Application Assistant

## Overview

The AI Job Application Assistant is a single-page web application that generates personalized cover letters using AI. Users input a job description and their resume, and the application leverages OpenAI's GPT-5 model to create tailored cover letters that highlight relevant experience and demonstrate cultural fit.

The application follows a utility-first design philosophy inspired by Material Design and Linear, emphasizing clarity, minimal distraction, and efficient workflows. It's built as a full-stack TypeScript application with a React frontend and Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, using Vite as the build tool and development server.

**UI Component Library**: Shadcn/ui components built on Radix UI primitives, configured with the "new-york" style variant. Components utilize Tailwind CSS for styling with a custom design system based on HSL color variables.

**Routing**: Wouter for lightweight client-side routing. The application has two routes:
- `/` - Home page with the cover letter generation interface
- `*` - 404 not found page

**State Management**: 
- TanStack Query (React Query) for server state management, API calls, and caching
- React hooks (useState) for local component state
- Custom hooks for mobile detection and toast notifications

**Form Handling**: React Hook Form is available via dependencies, though the current implementation uses controlled components with useState.

**Design System**:
- Typography: Inter font family for all UI elements
- Spacing: Tailwind's spacing scale (4, 6, 8, 12) for consistent rhythm
- Layout: Single-column, centered layout with max-w-4xl container
- Color scheme: Neutral base with customizable HSL color variables supporting light/dark modes
- Border radius: Custom values (9px, 6px, 3px) for visual consistency

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Design**: RESTful API with a single endpoint:
- `POST /api/generate-cover-letter` - Accepts job description and resume, returns generated cover letter

**Request Validation**: Zod schemas for runtime type validation and data sanitization. Shared schemas between frontend and backend ensure type safety across the stack.

**Error Handling**: Centralized error handling with appropriate HTTP status codes (400 for validation errors, 500 for server errors). Errors are logged to console and returned as JSON responses.

**Development Tooling**: 
- TSX for running TypeScript directly in development
- esbuild for production builds
- Vite middleware integration for HMR during development

### External Dependencies

**AI Service**: OpenAI API integration using the official OpenAI Node.js SDK. The application uses GPT-5 model for cover letter generation with configurable max tokens (2048) and custom system/user prompts.

**Database**: 
- Drizzle ORM configured for PostgreSQL via `@neondatabase/serverless` driver
- Database schema defined in `shared/schema.ts`
- Migrations managed through Drizzle Kit (output directory: `./migrations`)
- Current implementation includes User model infrastructure but doesn't actively use database persistence

**Environment Variables**:
- `DATABASE_URL` - PostgreSQL connection string (required for database configuration)
- `OPENAI_API_KEY` - OpenAI API key for GPT-5 access
- `NODE_ENV` - Environment indicator (development/production)

**Session Management**: Infrastructure present for PostgreSQL-based sessions via `connect-pg-simple`, though authentication is not currently implemented.

**Build & Deployment**:
- Development: Vite dev server with HMR, TSX for backend execution
- Production: Vite builds static assets to `dist/public`, esbuild bundles backend to `dist`
- Replit-specific plugins for development experience (error overlay, cartographer, dev banner)

### Data Flow

1. User enters job description and resume in the frontend form
2. Frontend validates minimum character requirements (10 characters each)
3. On submission, TanStack Query mutation sends POST request to `/api/generate-cover-letter`
4. Backend validates request body against Zod schema
5. Valid data is passed to OpenAI service with specialized prompts
6. OpenAI GPT-5 generates personalized cover letter
7. Response is returned to frontend and displayed in a copyable text area
8. Toast notifications provide feedback for success/error states

### Security & Validation

**Input Validation**: Multi-layer approach with client-side length checks and server-side Zod schema validation.

**API Security**: 
- CORS not explicitly configured (relies on same-origin for production)
- Raw body buffering enabled for webhook/signature verification scenarios
- No authentication/authorization currently implemented

**Error Exposure**: Development mode exposes detailed errors; production should mask internal error details.