import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import ws from "ws";
import * as schema from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import type {
  CoverLetter,
  InsertCoverLetter,
  JobDescriptionTemplate,
  InsertJobDescriptionTemplate,
  ResumeTemplate,
  InsertResumeTemplate,
} from "@shared/schema";

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });

export interface IStorage {
  // Cover Letters
  saveCoverLetter(coverLetter: InsertCoverLetter): Promise<CoverLetter>;
  getCoverLetters(): Promise<CoverLetter[]>;
  getCoverLetter(id: string): Promise<CoverLetter | undefined>;
  deleteCoverLetter(id: string): Promise<void>;

  // Job Description Templates
  createJobDescriptionTemplate(template: InsertJobDescriptionTemplate): Promise<JobDescriptionTemplate>;
  getJobDescriptionTemplates(): Promise<JobDescriptionTemplate[]>;
  getJobDescriptionTemplate(id: string): Promise<JobDescriptionTemplate | undefined>;
  updateJobDescriptionTemplate(id: string, template: Partial<InsertJobDescriptionTemplate>): Promise<JobDescriptionTemplate>;
  deleteJobDescriptionTemplate(id: string): Promise<void>;

  // Resume Templates
  createResumeTemplate(template: InsertResumeTemplate): Promise<ResumeTemplate>;
  getResumeTemplates(): Promise<ResumeTemplate[]>;
  getResumeTemplate(id: string): Promise<ResumeTemplate | undefined>;
  updateResumeTemplate(id: string, template: Partial<InsertResumeTemplate>): Promise<ResumeTemplate>;
  deleteResumeTemplate(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  // Cover Letters
  async saveCoverLetter(coverLetterData: InsertCoverLetter): Promise<CoverLetter> {
    const [coverLetter] = await db
      .insert(schema.coverLetters)
      .values(coverLetterData)
      .returning();
    return coverLetter;
  }

  async getCoverLetters(): Promise<CoverLetter[]> {
    return await db
      .select()
      .from(schema.coverLetters)
      .orderBy(desc(schema.coverLetters.createdAt));
  }

  async getCoverLetter(id: string): Promise<CoverLetter | undefined> {
    const [coverLetter] = await db
      .select()
      .from(schema.coverLetters)
      .where(eq(schema.coverLetters.id, id));
    return coverLetter;
  }

  async deleteCoverLetter(id: string): Promise<void> {
    await db
      .delete(schema.coverLetters)
      .where(eq(schema.coverLetters.id, id));
  }

  // Job Description Templates
  async createJobDescriptionTemplate(template: InsertJobDescriptionTemplate): Promise<JobDescriptionTemplate> {
    const [jobDescriptionTemplate] = await db
      .insert(schema.jobDescriptionTemplates)
      .values(template)
      .returning();
    return jobDescriptionTemplate;
  }

  async getJobDescriptionTemplates(): Promise<JobDescriptionTemplate[]> {
    return await db
      .select()
      .from(schema.jobDescriptionTemplates)
      .orderBy(desc(schema.jobDescriptionTemplates.createdAt));
  }

  async getJobDescriptionTemplate(id: string): Promise<JobDescriptionTemplate | undefined> {
    const [template] = await db
      .select()
      .from(schema.jobDescriptionTemplates)
      .where(eq(schema.jobDescriptionTemplates.id, id));
    return template;
  }

  async updateJobDescriptionTemplate(id: string, template: Partial<InsertJobDescriptionTemplate>): Promise<JobDescriptionTemplate> {
    const [updatedTemplate] = await db
      .update(schema.jobDescriptionTemplates)
      .set(template)
      .where(eq(schema.jobDescriptionTemplates.id, id))
      .returning();
    return updatedTemplate;
  }

  async deleteJobDescriptionTemplate(id: string): Promise<void> {
    await db
      .delete(schema.jobDescriptionTemplates)
      .where(eq(schema.jobDescriptionTemplates.id, id));
  }

  // Resume Templates
  async createResumeTemplate(template: InsertResumeTemplate): Promise<ResumeTemplate> {
    const [resumeTemplate] = await db
      .insert(schema.resumeTemplates)
      .values(template)
      .returning();
    return resumeTemplate;
  }

  async getResumeTemplates(): Promise<ResumeTemplate[]> {
    return await db
      .select()
      .from(schema.resumeTemplates)
      .orderBy(desc(schema.resumeTemplates.createdAt));
  }

  async getResumeTemplate(id: string): Promise<ResumeTemplate | undefined> {
    const [template] = await db
      .select()
      .from(schema.resumeTemplates)
      .where(eq(schema.resumeTemplates.id, id));
    return template;
  }

  async updateResumeTemplate(id: string, template: Partial<InsertResumeTemplate>): Promise<ResumeTemplate> {
    const [updatedTemplate] = await db
      .update(schema.resumeTemplates)
      .set(template)
      .where(eq(schema.resumeTemplates.id, id))
      .returning();
    return updatedTemplate;
  }

  async deleteResumeTemplate(id: string): Promise<void> {
    await db
      .delete(schema.resumeTemplates)
      .where(eq(schema.resumeTemplates.id, id));
  }
}

export const storage = new DbStorage();
