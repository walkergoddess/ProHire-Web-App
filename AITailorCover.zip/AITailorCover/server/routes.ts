import type { Express } from "express";
import { createServer, type Server } from "http";
import { generateCoverLetter } from "./openai";
import { storage } from "./storage";
import {
  generateCoverLetterSchema,
  insertCoverLetterSchema,
  insertJobDescriptionTemplateSchema,
  insertResumeTemplateSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate cover letter
  app.post("/api/generate-cover-letter", async (req, res) => {
    try {
      const result = generateCoverLetterSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const { jobDescription, resume, tone, length, focusAreas } = result.data;

      const coverLetter = await generateCoverLetter(
        jobDescription,
        resume,
        tone,
        length,
        focusAreas
      );

      res.json({ coverLetter });
    } catch (error) {
      console.error("Error in generate-cover-letter:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate cover letter" 
      });
    }
  });

  // Cover Letters endpoints
  app.post("/api/cover-letters", async (req, res) => {
    try {
      const result = insertCoverLetterSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const coverLetter = await storage.saveCoverLetter(result.data);
      res.json(coverLetter);
    } catch (error) {
      console.error("Error saving cover letter:", error);
      res.status(500).json({ 
        message: "Failed to save cover letter" 
      });
    }
  });

  app.get("/api/cover-letters", async (req, res) => {
    try {
      const coverLetters = await storage.getCoverLetters();
      res.json(coverLetters);
    } catch (error) {
      console.error("Error getting cover letters:", error);
      res.status(500).json({ 
        message: "Failed to get cover letters" 
      });
    }
  });

  app.get("/api/cover-letters/:id", async (req, res) => {
    try {
      const coverLetter = await storage.getCoverLetter(req.params.id);
      if (!coverLetter) {
        return res.status(404).json({ message: "Cover letter not found" });
      }
      res.json(coverLetter);
    } catch (error) {
      console.error("Error getting cover letter:", error);
      res.status(500).json({ 
        message: "Failed to get cover letter" 
      });
    }
  });

  app.delete("/api/cover-letters/:id", async (req, res) => {
    try {
      await storage.deleteCoverLetter(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting cover letter:", error);
      res.status(500).json({ 
        message: "Failed to delete cover letter" 
      });
    }
  });

  // Job Description Templates endpoints
  app.post("/api/job-templates", async (req, res) => {
    try {
      const result = insertJobDescriptionTemplateSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const template = await storage.createJobDescriptionTemplate(result.data);
      res.json(template);
    } catch (error) {
      console.error("Error creating job template:", error);
      res.status(500).json({ 
        message: "Failed to create job template" 
      });
    }
  });

  app.get("/api/job-templates", async (req, res) => {
    try {
      const templates = await storage.getJobDescriptionTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error getting job templates:", error);
      res.status(500).json({ 
        message: "Failed to get job templates" 
      });
    }
  });

  app.put("/api/job-templates/:id", async (req, res) => {
    try {
      const result = insertJobDescriptionTemplateSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const template = await storage.updateJobDescriptionTemplate(req.params.id, result.data);
      res.json(template);
    } catch (error) {
      console.error("Error updating job template:", error);
      res.status(500).json({ 
        message: "Failed to update job template" 
      });
    }
  });

  app.delete("/api/job-templates/:id", async (req, res) => {
    try {
      await storage.deleteJobDescriptionTemplate(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting job template:", error);
      res.status(500).json({ 
        message: "Failed to delete job template" 
      });
    }
  });

  // Resume Templates endpoints
  app.post("/api/resume-templates", async (req, res) => {
    try {
      const result = insertResumeTemplateSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const template = await storage.createResumeTemplate(result.data);
      res.json(template);
    } catch (error) {
      console.error("Error creating resume template:", error);
      res.status(500).json({ 
        message: "Failed to create resume template" 
      });
    }
  });

  app.get("/api/resume-templates", async (req, res) => {
    try {
      const templates = await storage.getResumeTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error getting resume templates:", error);
      res.status(500).json({ 
        message: "Failed to get resume templates" 
      });
    }
  });

  app.put("/api/resume-templates/:id", async (req, res) => {
    try {
      const result = insertResumeTemplateSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input",
          errors: result.error.issues 
        });
      }

      const template = await storage.updateResumeTemplate(req.params.id, result.data);
      res.json(template);
    } catch (error) {
      console.error("Error updating resume template:", error);
      res.status(500).json({ 
        message: "Failed to update resume template" 
      });
    }
  });

  app.delete("/api/resume-templates/:id", async (req, res) => {
    try {
      await storage.deleteResumeTemplate(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting resume template:", error);
      res.status(500).json({ 
        message: "Failed to delete resume template" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
