import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
// This is using OpenAI's API, which points to OpenAI's API servers and requires your own API key.
let openai: OpenAI | null = null;

function getOpenAI(): OpenAI {
  if (!openai) {
    openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY 
    });
  }
  return openai;
}

export async function generateCoverLetter(
  jobDescription: string,
  resume: string,
  tone?: "professional" | "casual" | "enthusiastic",
  length?: "short" | "medium" | "long",
  focusAreas?: string
): Promise<string> {
  try {
    // Build customization instructions
    const toneInstructions = {
      professional: "Use a formal, polished tone suitable for corporate environments.",
      casual: "Use a friendly, conversational tone while maintaining professionalism.",
      enthusiastic: "Use an energetic, passionate tone that conveys excitement about the opportunity."
    };
    
    const lengthInstructions = {
      short: "Keep it brief - 2-3 concise paragraphs (approximately 150-200 words).",
      medium: "Standard length - 3-4 well-developed paragraphs (approximately 250-350 words).",
      long: "Comprehensive - 4-5 detailed paragraphs (approximately 400-500 words)."
    };

    const toneInstruction = tone ? toneInstructions[tone] : toneInstructions.professional;
    const lengthInstruction = length ? lengthInstructions[length] : lengthInstructions.medium;
    const focusInstruction = focusAreas ? `\n\nSPECIAL FOCUS AREAS: Pay particular attention to: ${focusAreas}` : "";

    const prompt = `You are a professional career advisor and cover letter expert. Generate a compelling, tailored cover letter based on the following:

JOB DESCRIPTION:
${jobDescription}

CANDIDATE'S RESUME:
${resume}${focusInstruction}

Generate a professional cover letter that:
1. Is personalized to this specific job and candidate
2. Highlights relevant experience and skills from the resume that match the job requirements
3. Shows genuine enthusiasm and cultural fit
4. ${toneInstruction}
5. ${lengthInstruction}
6. Includes a strong opening, compelling body, and confident closing
7. Avoids generic phrases and focuses on specific achievements

Return only the cover letter text, properly formatted with paragraphs. Do not include placeholder text like "[Your Name]" or "[Date]" - write it as if ready to send.`;

    const response = await getOpenAI().chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert career advisor who writes compelling, personalized cover letters that help candidates stand out."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_completion_tokens: 2048,
    });

    const coverLetter = response.choices[0].message.content;
    
    if (!coverLetter) {
      throw new Error("No cover letter generated");
    }

    return coverLetter.trim();
  } catch (error) {
    console.error("Error generating cover letter:", error);
    throw new Error("Failed to generate cover letter. Please try again.");
  }
}
