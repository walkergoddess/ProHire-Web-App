import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { FileText, Briefcase, Plus, Trash2, Loader2, BookOpen, Sparkles, Library as LibraryIcon, Edit } from "lucide-react";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { JobDescriptionTemplate, ResumeTemplate, InsertJobDescriptionTemplate, InsertResumeTemplate } from "@shared/schema";

export default function Templates() {
  const { toast } = useToast();
  const [showJobForm, setShowJobForm] = useState(false);
  const [showResumeForm, setShowResumeForm] = useState(false);
  const [editingJobId, setEditingJobId] = useState<string | null>(null);
  const [editingResumeId, setEditingResumeId] = useState<string | null>(null);
  const [jobTitle, setJobTitle] = useState("");
  const [jobContent, setJobContent] = useState("");
  const [jobCategory, setJobCategory] = useState("");
  const [resumeTitle, setResumeTitle] = useState("");
  const [resumeContent, setResumeContent] = useState("");
  const [resumeCategory, setResumeCategory] = useState("");

  const { data: jobTemplates, isLoading: loadingJobs } = useQuery<JobDescriptionTemplate[]>({
    queryKey: ["/api/job-templates"],
  });

  const { data: resumeTemplates, isLoading: loadingResumes } = useQuery<ResumeTemplate[]>({
    queryKey: ["/api/resume-templates"],
  });

  const createJobMutation = useMutation({
    mutationFn: async (data: InsertJobDescriptionTemplate) => {
      const response = await apiRequest("POST", "/api/job-templates", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-templates"] });
      setJobTitle("");
      setJobContent("");
      setJobCategory("");
      setShowJobForm(false);
      toast({
        title: "Template created",
        description: "Job description template added successfully.",
      });
    },
  });

  const createResumeMutation = useMutation({
    mutationFn: async (data: InsertResumeTemplate) => {
      const response = await apiRequest("POST", "/api/resume-templates", data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resume-templates"] });
      setResumeTitle("");
      setResumeContent("");
      setResumeCategory("");
      setShowResumeForm(false);
      toast({
        title: "Template created",
        description: "Resume template added successfully.",
      });
    },
  });

  const deleteJobMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/job-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-templates"] });
      toast({
        title: "Template deleted",
        description: "Job description template removed.",
      });
    },
  });

  const deleteResumeMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/resume-templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resume-templates"] });
      toast({
        title: "Template deleted",
        description: "Resume template removed.",
      });
    },
  });

  const updateJobMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertJobDescriptionTemplate> }) => {
      const response = await apiRequest("PUT", `/api/job-templates/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/job-templates"] });
      setEditingJobId(null);
      setJobTitle("");
      setJobContent("");
      setJobCategory("");
      toast({
        title: "Template updated",
        description: "Job description template saved successfully.",
      });
    },
  });

  const updateResumeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertResumeTemplate> }) => {
      const response = await apiRequest("PUT", `/api/resume-templates/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resume-templates"] });
      setEditingResumeId(null);
      setResumeTitle("");
      setResumeContent("");
      setResumeCategory("");
      toast({
        title: "Template updated",
        description: "Resume template saved successfully.",
      });
    },
  });

  const handleCreateJob = () => {
    if (!jobTitle.trim() || !jobContent.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both title and content.",
        variant: "destructive",
      });
      return;
    }

    createJobMutation.mutate({
      title: jobTitle,
      content: jobContent,
      category: jobCategory || null,
    });
  };

  const handleCreateResume = () => {
    if (!resumeTitle.trim() || !resumeContent.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both title and content.",
        variant: "destructive",
      });
      return;
    }

    createResumeMutation.mutate({
      title: resumeTitle,
      content: resumeContent,
      category: resumeCategory || null,
    });
  };

  const handleEditJob = (template: JobDescriptionTemplate) => {
    setEditingJobId(template.id);
    setJobTitle(template.title);
    setJobContent(template.content);
    setJobCategory(template.category || "");
    setShowJobForm(true);
  };

  const handleEditResume = (template: ResumeTemplate) => {
    setEditingResumeId(template.id);
    setResumeTitle(template.title);
    setResumeContent(template.content);
    setResumeCategory(template.category || "");
    setShowResumeForm(true);
  };

  const handleUpdateJob = () => {
    if (!editingJobId || !jobTitle.trim() || !jobContent.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both title and content.",
        variant: "destructive",
      });
      return;
    }

    updateJobMutation.mutate({
      id: editingJobId,
      data: {
        title: jobTitle,
        content: jobContent,
        category: jobCategory || null,
      },
    });
  };

  const handleUpdateResume = () => {
    if (!editingResumeId || !resumeTitle.trim() || !resumeContent.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both title and content.",
        variant: "destructive",
      });
      return;
    }

    updateResumeMutation.mutate({
      id: editingResumeId,
      data: {
        title: resumeTitle,
        content: resumeContent,
        category: resumeCategory || null,
      },
    });
  };

  const handleCancelJobEdit = () => {
    setEditingJobId(null);
    setJobTitle("");
    setJobContent("");
    setJobCategory("");
    setShowJobForm(false);
  };

  const handleCancelResumeEdit = () => {
    setEditingResumeId(null);
    setResumeTitle("");
    setResumeContent("");
    setResumeCategory("");
    setShowResumeForm(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-12">
        <header className="mb-12 border-b pb-8 text-center">
          <div className="flex flex-col items-center gap-3 mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              Templates Library
            </h1>
          </div>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            Manage your job description and resume templates for quick generation
          </p>
          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <Button
              data-testid="button-home"
              variant="outline"
              asChild
            >
              <Link href="/">
                <Sparkles className="h-4 w-4" />
                Generate New
              </Link>
            </Button>
            <Button
              data-testid="button-library"
              variant="outline"
              asChild
            >
              <Link href="/library">
                <LibraryIcon className="h-4 w-4" />
                My Library
              </Link>
            </Button>
          </div>
        </header>

        <Tabs defaultValue="jobs" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="jobs" data-testid="tab-job-templates">
              <Briefcase className="h-4 w-4 mr-2" />
              Job Descriptions
            </TabsTrigger>
            <TabsTrigger value="resumes" data-testid="tab-resume-templates">
              <FileText className="h-4 w-4 mr-2" />
              Resumes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="jobs" className="space-y-6">
            {!showJobForm && (
              <div className="flex justify-end">
                <Button
                  data-testid="button-add-job-template"
                  onClick={() => setShowJobForm(true)}
                >
                  <Plus className="h-4 w-4" />
                  Add Template
                </Button>
              </div>
            )}

            {showJobForm && (
              <Card data-testid="card-job-form">
                <CardHeader>
                  <CardTitle>Create Job Description Template</CardTitle>
                  <CardDescription>Add a new template to your library</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="job-title">Title</Label>
                    <Input
                      id="job-title"
                      data-testid="input-job-title"
                      placeholder="e.g., Senior Software Engineer"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="job-category">Category (Optional)</Label>
                    <Input
                      id="job-category"
                      data-testid="input-job-category"
                      placeholder="e.g., Engineering, Marketing"
                      value={jobCategory}
                      onChange={(e) => setJobCategory(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="job-content">Job Description</Label>
                    <Textarea
                      id="job-content"
                      data-testid="textarea-job-content"
                      placeholder="Paste or write the job description here..."
                      value={jobContent}
                      onChange={(e) => setJobContent(e.target.value)}
                      className="min-h-48"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      data-testid="button-save-job"
                      onClick={editingJobId ? handleUpdateJob : handleCreateJob}
                      disabled={createJobMutation.isPending || updateJobMutation.isPending}
                    >
                      {(createJobMutation.isPending || updateJobMutation.isPending) ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : editingJobId ? (
                        "Update Template"
                      ) : (
                        "Save Template"
                      )}
                    </Button>
                    <Button
                      data-testid="button-cancel-job"
                      variant="outline"
                      onClick={handleCancelJobEdit}
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {loadingJobs ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : jobTemplates && jobTemplates.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {jobTemplates.map((template) => (
                  <Card key={template.id} data-testid={`card-job-${template.id}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                            <Briefcase className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <CardTitle className="text-lg line-clamp-1">
                              {template.title}
                            </CardTitle>
                            {template.category && (
                              <CardDescription className="mt-1">
                                {template.category}
                              </CardDescription>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            data-testid={`button-edit-job-${template.id}`}
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditJob(template)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            data-testid={`button-delete-job-${template.id}`}
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteJobMutation.mutate(template.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {template.content}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="text-center py-12">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center gap-4">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                      <Briefcase className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">No job templates yet</h3>
                      <p className="text-sm text-muted-foreground">
                        Create templates for frequently used job descriptions
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="resumes" className="space-y-6">
            {!showResumeForm && (
              <div className="flex justify-end">
                <Button
                  data-testid="button-add-resume-template"
                  onClick={() => setShowResumeForm(true)}
                >
                  <Plus className="h-4 w-4" />
                  Add Template
                </Button>
              </div>
            )}

            {showResumeForm && (
              <Card data-testid="card-resume-form">
                <CardHeader>
                  <CardTitle>Create Resume Template</CardTitle>
                  <CardDescription>Add a new template to your library</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="resume-title">Title</Label>
                    <Input
                      id="resume-title"
                      data-testid="input-resume-title"
                      placeholder="e.g., Software Developer Resume"
                      value={resumeTitle}
                      onChange={(e) => setResumeTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resume-category">Category (Optional)</Label>
                    <Input
                      id="resume-category"
                      data-testid="input-resume-category"
                      placeholder="e.g., Technical, Creative"
                      value={resumeCategory}
                      onChange={(e) => setResumeCategory(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resume-content">Resume Content</Label>
                    <Textarea
                      id="resume-content"
                      data-testid="textarea-resume-content"
                      placeholder="Paste or write the resume content here..."
                      value={resumeContent}
                      onChange={(e) => setResumeContent(e.target.value)}
                      className="min-h-64"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      data-testid="button-save-resume"
                      onClick={editingResumeId ? handleUpdateResume : handleCreateResume}
                      disabled={createResumeMutation.isPending || updateResumeMutation.isPending}
                    >
                      {(createResumeMutation.isPending || updateResumeMutation.isPending) ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : editingResumeId ? (
                        "Update Template"
                      ) : (
                        "Save Template"
                      )}
                    </Button>
                    <Button
                      data-testid="button-cancel-resume"
                      variant="outline"
                      onClick={handleCancelResumeEdit}
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {loadingResumes ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : resumeTemplates && resumeTemplates.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {resumeTemplates.map((template) => (
                  <Card key={template.id} data-testid={`card-resume-${template.id}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                            <FileText className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <CardTitle className="text-lg line-clamp-1">
                              {template.title}
                            </CardTitle>
                            {template.category && (
                              <CardDescription className="mt-1">
                                {template.category}
                              </CardDescription>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            data-testid={`button-edit-resume-${template.id}`}
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditResume(template)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            data-testid={`button-delete-resume-${template.id}`}
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteResumeMutation.mutate(template.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {template.content}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="text-center py-12">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center gap-4">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">No resume templates yet</h3>
                      <p className="text-sm text-muted-foreground">
                        Create templates for different versions of your resume
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
