import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Library as LibraryIcon, Trash2, FileText, Calendar, Loader2, Sparkles, BookOpen } from "lucide-react";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { CoverLetter } from "@shared/schema";
import { format } from "date-fns";

export default function Library() {
  const { toast } = useToast();

  const { data: coverLetters, isLoading } = useQuery<CoverLetter[]>({
    queryKey: ["/api/cover-letters"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/cover-letters/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cover-letters"] });
      toast({
        title: "Cover letter deleted",
        description: "The cover letter has been removed from your library.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Failed to delete the cover letter. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this cover letter?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-12">
        <header className="mb-12 border-b pb-8 text-center">
          <div className="flex flex-col items-center gap-3 mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <LibraryIcon className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              My Cover Letters
            </h1>
          </div>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            Browse, manage, and export your saved cover letters
          </p>
          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <Button
              data-testid="button-home"
              variant="outline"
              asChild
            >
              <Link href="/">
                <Sparkles className="h-4 w-4" />
                Generate New
              </Link>
            </Button>
            <Button
              data-testid="button-templates"
              variant="outline"
              asChild
            >
              <Link href="/templates">
                <BookOpen className="h-4 w-4" />
                Templates
              </Link>
            </Button>
          </div>
        </header>

        <main>
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : coverLetters && coverLetters.length > 0 ? (
            <div className="grid gap-6 md:grid-cols-2">
              {coverLetters.map((letter) => (
                <Card key={letter.id} data-testid={`card-cover-letter-${letter.id}`} className="hover-elevate">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                          <FileText className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-lg line-clamp-1">
                            {letter.jobTitle || "Cover Letter"}
                          </CardTitle>
                          {letter.company && (
                            <CardDescription className="mt-1 line-clamp-1">
                              {letter.company}
                            </CardDescription>
                          )}
                        </div>
                      </div>
                      <Button
                        data-testid={`button-delete-${letter.id}`}
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(letter.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        <span data-testid={`text-date-${letter.id}`}>
                          {format(new Date(letter.createdAt), "MMM d, yyyy")}
                        </span>
                        {letter.tone && (
                          <>
                            <span>•</span>
                            <span data-testid={`text-tone-${letter.id}`}>
                              {letter.tone.charAt(0).toUpperCase() + letter.tone.slice(1)} tone
                            </span>
                          </>
                        )}
                        {letter.length && (
                          <>
                            <span>•</span>
                            <span data-testid={`text-length-${letter.id}`}>
                              {letter.length.charAt(0).toUpperCase() + letter.length.slice(1)}
                            </span>
                          </>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-3" data-testid={`text-preview-${letter.id}`}>
                        {letter.coverLetter}
                      </p>
                      <div className="flex gap-2 pt-2">
                        <Button
                          data-testid={`button-view-${letter.id}`}
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => {
                            // TODO: Navigate to view/edit page
                            toast({
                              title: "Coming soon",
                              description: "View and edit functionality will be added next.",
                            });
                          }}
                        >
                          View Full Letter
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center py-12">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                    <LibraryIcon className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">No saved cover letters yet</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Generate and save cover letters to build your library
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
