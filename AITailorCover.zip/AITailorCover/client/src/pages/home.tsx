import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Copy, Check, FileText, Briefcase, Loader2, Save, Library, Download, BookTemplate, ChevronDown } from "lucide-react";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { GenerateCoverLetterRequest, GenerateCoverLetterResponse, InsertCoverLetter } from "@shared/schema";
import { jsPDF } from "jspdf";
import { Document, Packer, Paragraph, TextRun } from "docx";

export default function Home() {
  const [jobDescription, setJobDescription] = useState("");
  const [resume, setResume] = useState("");
  const [coverLetter, setCoverLetter] = useState("");
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [tone, setTone] = useState<"professional" | "casual" | "enthusiastic">("professional");
  const [length, setLength] = useState<"short" | "medium" | "long">("medium");
  const [focusAreas, setFocusAreas] = useState("");
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: GenerateCoverLetterRequest) => {
      const response = await apiRequest(
        "POST",
        "/api/generate-cover-letter",
        data
      );
      return await response.json() as GenerateCoverLetterResponse;
    },
    onSuccess: (data) => {
      setCoverLetter(data.coverLetter);
      setSaved(false);
      toast({
        title: "Cover letter generated!",
        description: "Your tailored cover letter is ready.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!jobDescription.trim() || !resume.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both job description and resume.",
        variant: "destructive",
      });
      return;
    }

    generateMutation.mutate({
      jobDescription: jobDescription.trim(),
      resume: resume.trim(),
      tone,
      length,
      focusAreas: focusAreas.trim() || undefined,
    });
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const data: InsertCoverLetter = {
        jobDescription,
        resume,
        coverLetter,
        jobTitle: null,
        company: null,
        tone: tone || null,
        length: length || null,
        focusAreas: focusAreas.trim() || null,
      };
      const response = await apiRequest("POST", "/api/cover-letters", data);
      return await response.json();
    },
    onSuccess: () => {
      setSaved(true);
      queryClient.invalidateQueries({ queryKey: ["/api/cover-letters"] });
      toast({
        title: "Cover letter saved!",
        description: "Added to your library.",
      });
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Failed to save the cover letter. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!coverLetter) return;
    saveMutation.mutate();
  };

  const handleCopy = async () => {
    if (!coverLetter) return;
    
    try {
      await navigator.clipboard.writeText(coverLetter);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Cover letter copied to clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please try selecting and copying manually.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadText = () => {
    if (!coverLetter) return;

    const blob = new Blob([coverLetter], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `cover-letter-${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded",
      description: "Cover letter saved as text file.",
    });
  };

  const handleDownloadPDF = () => {
    if (!coverLetter) return;

    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const maxWidth = pageWidth - 2 * margin;
      const lineHeight = 7;
      
      doc.setFont("helvetica");
      doc.setFontSize(11);
      
      const lines = doc.splitTextToSize(coverLetter, maxWidth);
      let y = margin;
      
      lines.forEach((line: string) => {
        if (y + lineHeight > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(line, margin, y);
        y += lineHeight;
      });

      doc.save(`cover-letter-${Date.now()}.pdf`);

      toast({
        title: "Downloaded",
        description: "Cover letter saved as PDF.",
      });
    } catch (err) {
      toast({
        title: "Download failed",
        description: "Could not create PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadDOCX = async () => {
    if (!coverLetter) return;

    try {
      const paragraphs = coverLetter.split("\n\n").map(
        (para) =>
          new Paragraph({
            children: [new TextRun({ text: para, size: 22 })],
            spacing: { after: 200 },
          })
      );

      const doc = new Document({
        sections: [
          {
            properties: {},
            children: paragraphs,
          },
        ],
      });

      const blob = await Packer.toBlob(doc);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `cover-letter-${Date.now()}.docx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast({
        title: "Downloaded",
        description: "Cover letter saved as Word document.",
      });
    } catch (err) {
      toast({
        title: "Download failed",
        description: "Could not create Word document. Please try again.",
        variant: "destructive",
      });
    }
  };

  const jobDescriptionLength = jobDescription.length;
  const resumeLength = resume.length;
  const isGenerating = generateMutation.isPending;
  const canGenerate = jobDescription.trim().length >= 10 && resume.trim().length >= 10 && !isGenerating;

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-4xl px-4 py-8 md:px-8 md:py-12">
        <header className="mb-12 border-b pb-8 text-center">
          <div className="flex flex-col items-center gap-3 mb-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">
              AI Job Application Assistant
            </h1>
          </div>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            Generate professional, tailored cover letters in seconds. Paste your job description and resume below, and let AI craft the perfect cover letter for you.
          </p>
          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <Button
              data-testid="button-library"
              variant="outline"
              asChild
            >
              <Link href="/library">
                <Library className="h-4 w-4" />
                My Library
              </Link>
            </Button>
            <Button
              data-testid="button-templates"
              variant="outline"
              asChild
            >
              <Link href="/templates">
                <BookTemplate className="h-4 w-4" />
                Templates
              </Link>
            </Button>
          </div>
        </header>

        <main className="space-y-6">
          <Card data-testid="card-job-description">
            <CardHeader>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <Briefcase className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">Job Description</CardTitle>
                  <CardDescription className="mt-1">
                    Paste the complete job posting or description
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Label htmlFor="job-description" className="text-base font-medium">
                  Job Details
                </Label>
                <Textarea
                  id="job-description"
                  data-testid="input-job-description"
                  placeholder="Paste the job description here, including requirements, responsibilities, and qualifications..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  className="min-h-48 resize-y font-mono text-sm"
                  disabled={isGenerating}
                />
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground" data-testid="text-job-description-count">
                    {jobDescriptionLength > 0 ? `${jobDescriptionLength} characters` : "Minimum 10 characters required"}
                  </p>
                  {jobDescriptionLength >= 10 && (
                    <p className="text-xs text-primary font-medium flex items-center gap-1" data-testid="text-job-description-ready">
                      <Check className="h-3 w-3" />
                      Ready
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-resume">
            <CardHeader>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">Your Resume</CardTitle>
                  <CardDescription className="mt-1">
                    Paste your resume or CV content
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Label htmlFor="resume" className="text-base font-medium">
                  Resume Content
                </Label>
                <Textarea
                  id="resume"
                  data-testid="input-resume"
                  placeholder="Paste your resume here, including your experience, skills, education, and achievements..."
                  value={resume}
                  onChange={(e) => setResume(e.target.value)}
                  className="min-h-64 resize-y font-mono text-sm"
                  disabled={isGenerating}
                />
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground" data-testid="text-resume-count">
                    {resumeLength > 0 ? `${resumeLength} characters` : "Minimum 10 characters required"}
                  </p>
                  {resumeLength >= 10 && (
                    <p className="text-xs text-primary font-medium flex items-center gap-1" data-testid="text-resume-ready">
                      <Check className="h-3 w-3" />
                      Ready
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-customization">
            <CardHeader>
              <CardTitle className="text-lg">Customization Options</CardTitle>
              <CardDescription>
                Tailor the tone, length, and focus of your cover letter
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="tone-select" className="text-sm font-medium">
                    Tone
                  </Label>
                  <Select value={tone} onValueChange={(value: any) => setTone(value)}>
                    <SelectTrigger id="tone-select" data-testid="select-tone">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                      <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="length-select" className="text-sm font-medium">
                    Length
                  </Label>
                  <Select value={length} onValueChange={(value: any) => setLength(value)}>
                    <SelectTrigger id="length-select" data-testid="select-length">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="short">Short</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="long">Long</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 md:col-span-1">
                  <Label htmlFor="focus-areas" className="text-sm font-medium">
                    Focus Areas (Optional)
                  </Label>
                  <Input
                    id="focus-areas"
                    data-testid="input-focus-areas"
                    placeholder="e.g., leadership, teamwork"
                    value={focusAreas}
                    onChange={(e) => setFocusAreas(e.target.value)}
                    disabled={isGenerating}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center py-4">
            <Button
              data-testid="button-generate"
              size="lg"
              onClick={handleGenerate}
              disabled={!canGenerate}
              className="min-w-64"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-5 w-5" />
                  Generate Tailored Cover Letter
                </>
              )}
            </Button>
          </div>

          <Card data-testid="card-output" className={isGenerating ? "opacity-60" : ""}>
            <CardHeader>
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <CardTitle className="text-lg">Generated Cover Letter</CardTitle>
                  <CardDescription className="mt-1">
                    Your AI-tailored cover letter will appear here
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Label htmlFor="cover-letter" className="text-base font-medium">
                  Cover Letter (Editable)
                </Label>
                <div className="relative">
                  <Textarea
                    id="cover-letter"
                    data-testid="output-cover-letter"
                    placeholder="Your tailored cover letter will appear here..."
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    className="min-h-80 resize-y font-mono text-sm"
                  />
                  {isGenerating && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background/50 rounded-md">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  )}
                </div>
                {coverLetter && !isGenerating && (
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground" data-testid="text-cover-letter-count">
                        {coverLetter.length} characters
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        data-testid="button-save"
                        variant="default"
                        size="sm"
                        onClick={handleSave}
                        disabled={saveMutation.isPending || saved}
                        className="flex-1"
                      >
                        {saved ? (
                          <>
                            <Check className="h-4 w-4" />
                            Saved
                          </>
                        ) : saveMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4" />
                            Save
                          </>
                        )}
                      </Button>
                      <Button
                        data-testid="button-copy"
                        variant="outline"
                        size="sm"
                        onClick={handleCopy}
                        className="flex-1"
                      >
                        {copied ? (
                          <>
                            <Check className="h-4 w-4" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4" />
                            Copy
                          </>
                        )}
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            data-testid="button-download"
                            variant="outline"
                            size="sm"
                            className="flex-1"
                          >
                            <Download className="h-4 w-4" />
                            Export
                            <ChevronDown className="h-3 w-3 ml-1" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={handleDownloadText} data-testid="button-download-text">
                            <FileText className="h-4 w-4 mr-2" />
                            Text File (.txt)
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleDownloadPDF} data-testid="button-download-pdf">
                            <FileText className="h-4 w-4 mr-2" />
                            PDF (.pdf)
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={handleDownloadDOCX} data-testid="button-download-docx">
                            <FileText className="h-4 w-4 mr-2" />
                            Word (.docx)
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </main>

        <footer className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
          <p>Powered by AI • Generate professional cover letters instantly</p>
        </footer>
      </div>
    </div>
  );
}
