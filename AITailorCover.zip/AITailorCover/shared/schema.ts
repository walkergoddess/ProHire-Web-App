import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Cover Letters table
export const coverLetters = pgTable("cover_letters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  jobDescription: text("job_description").notNull(),
  resume: text("resume").notNull(),
  coverLetter: text("cover_letter").notNull(),
  jobTitle: text("job_title"),
  company: text("company"),
  tone: text("tone"),
  length: text("length"),
  focusAreas: text("focus_areas"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCoverLetterSchema = createInsertSchema(coverLetters).omit({
  id: true,
  createdAt: true,
});

export type InsertCoverLetter = z.infer<typeof insertCoverLetterSchema>;
export type CoverLetter = typeof coverLetters.$inferSelect;

// Job Description Templates
export const jobDescriptionTemplates = pgTable("job_description_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJobDescriptionTemplateSchema = createInsertSchema(jobDescriptionTemplates).omit({
  id: true,
  createdAt: true,
});

export type InsertJobDescriptionTemplate = z.infer<typeof insertJobDescriptionTemplateSchema>;
export type JobDescriptionTemplate = typeof jobDescriptionTemplates.$inferSelect;

// Resume Templates
export const resumeTemplates = pgTable("resume_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResumeTemplateSchema = createInsertSchema(resumeTemplates).omit({
  id: true,
  createdAt: true,
});

export type InsertResumeTemplate = z.infer<typeof insertResumeTemplateSchema>;
export type ResumeTemplate = typeof resumeTemplates.$inferSelect;

// API Request/Response schemas
export const generateCoverLetterSchema = z.object({
  jobDescription: z.string().min(10, "Job description must be at least 10 characters"),
  resume: z.string().min(10, "Resume must be at least 10 characters"),
  tone: z.enum(["professional", "casual", "enthusiastic"]).optional(),
  length: z.enum(["short", "medium", "long"]).optional(),
  focusAreas: z.string().optional(),
});

export type GenerateCoverLetterRequest = z.infer<typeof generateCoverLetterSchema>;

export interface GenerateCoverLetterResponse {
  coverLetter: string;
}
